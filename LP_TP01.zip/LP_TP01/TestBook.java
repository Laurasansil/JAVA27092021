public class TestBook {
	public static void main(String[] args) {
		Author[] authors = new Author[3];
		authors[0] = new Author("roberto", "roberto@email.com", 'm');
		authors[1] = new Author("rogeria", "rogerinha@email.com", 'f');
		authors[2] = new Author("jujuba", "jujuba@email.com", 'f');

		Book book = new Book("Como ser brabo", authors, 20.50, 15);
		System.out.println(book);
	}
}
