// classe de teste de Author
public class Teste {
	public static void main(String[] args) {
		Author author = new Author("Roger", "roger@email.com", 'm');
		String toString = author.toString();
		System.out.println(toString);

		author.setEmail("roger2@email.com");

		String nomeAutor = author.getName();
		String emailAutor = author.getEmail();
		char generoAutor = author.getGender();

		System.out.printf("nome= %s, email= %s, gender= %c\n", nomeAutor, emailAutor, generoAutor);
	}
}
